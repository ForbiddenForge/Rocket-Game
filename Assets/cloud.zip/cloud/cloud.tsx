<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.3.1" name="cloud" tilewidth="32" tileheight="32" spacing="1" margin="1" tilecount="49" columns="7">
 <image source="cloud.png" width="256" height="256"/>
</tileset>
